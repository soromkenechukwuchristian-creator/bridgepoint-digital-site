# BridgePoint Digital website

This is a static website. The homepage is `index.html`.

## Publish with GitHub Pages
1. In your repository, choose **Add file → Upload files**.
2. Upload `index.html` to the repository's top level (not inside another folder).
3. Commit the upload.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
6. After GitHub Pages finishes publishing, your site will be available at:
   `https://YOUR-GITHUB-USERNAME.github.io/bridgepoint-digital-site/`
